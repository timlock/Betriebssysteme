Praktikum Betriebssysteme (WebBot mit Multi-Threading)
......................................................

Inhalt: 

- Prosumer_Example / Prosumer_Example_C++11:

  Bsp. für die Implementierungen von Threads in C / C++ nach dem Producer / Consumer-Prinzip.

  Die Bsp. koennen mit 'make' erzeugt werden.
	* 'make clean': saeubert das Projekt
	* 'make run': startet das Programm

- Web_Request: Bibliothek zum Lesen zum Download von URLs per libcurl
  
  Die Bibliothek erlaubt auch den Zugriff abgesicherte Sites (https://....).
  Im Ordner befindet sich ein Programm zum Test der Funktionen (simple_bot.c). 
  Das Projekt kann per 'make' erzeugt und per Skript aufgerufen werden.

hje, Nov 2020
