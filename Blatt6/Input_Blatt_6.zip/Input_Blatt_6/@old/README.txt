Praktikum Betriebssysteme (Aufgabe 6)
.....................................

Inhalt: 

- Prosumer_Example / Prosumer_Example_C++11:

  Bsp. für die Implementierungen von Threads in C / C++ nach dem Producer / Consumer-Prinzip.

- Web_Request: Bibliothek zum Lesen zum Download von URLs per libcurl
  
  Die Bibliothek erlaubt auch den Zugriff abgesicherte Sites (https://....).
  Im Ordner befindet sich ein Programm zum Test der Funktionen (simple_bot.c). 
  Das Projekt kann per make erzeugt und per Skript aufgerufen werden.

- Proxy-Server: 

  Die Bibliothek in Web_Request ermöglicht die Einstellung von Verzögerungen 
  zum Zugriff auf URLs. Alternativ können die Requests auch über ein separates Programm, 
  einen Proxy-Server geführt werden. Das ist realitätsnäher, wird aber für die Aufgabe 
  nicht unbedingt benötigt. 

hje, Nov 2019
